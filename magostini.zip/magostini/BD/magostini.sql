-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-06-2019 a las 20:00:47
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `magostini`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `canciones`
--

CREATE TABLE `canciones` (
  `track_id` int(11) NOT NULL,
  `track_nombre` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `track_duracion` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `track_colaborador` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL,
  `track_letra` varchar(2000) COLLATE utf8_spanish_ci DEFAULT NULL,
  `track_track` int(2) DEFAULT NULL,
  `id_disco` int(6) DEFAULT NULL,
  `cd_nombre` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `c_video` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `canciones`
--

INSERT INTO `canciones` (`track_id`, `track_nombre`, `track_duracion`, `track_colaborador`, `track_letra`, `track_track`, `id_disco`, `cd_nombre`, `c_video`) VALUES
(1, 'Quiero amarte', '03:05', 'Mariano Agostini', 'Es una pena que no quieras ya de mis caricias,\r\npor que te amaba con el alma entera y con mi corazon,\r\nyo que sonaba regalarte siempre cada primavera \r\nun poema una rosa una carta y una cancion,\r\n\r\nahora que ya no te tengo me quede can solo y triste,\r\npensando quien te besara quien te hara el amor,\r\n\r\nno me averguenza decir que te extrano por las madrugadas\r\ny que me cuesta despertar sin ti sin sentir tu calor,\r\nme haces falta amor.\r\n\r\nAy! quiero amarte\r\ny que mi corazon no sufra ya por tu amor\r\ny acariciarte, que me llenes de ternura y de pasion.', 1, 1, 'Quiero Amarte', '<iframe width=\"200\" height=\"200\" frameborder=\"0\" src=\"https://www.youtube.com/embed/Nz8UD6aqbmg\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(2, 'Chau Chau Chau', '03:20', 'Mariano Agostini', 'Ya no quiero ser tu amigo, tampoco quiero ser tu amor,\r\nya no quiero mas ni verte, nuestra historia termino,\r\nya me canse de tus mentiras por eso ahora yo me voy,\r\nsabias que yo te queria pero eso nunca te importo,\r\npor eso yo me voy lejos de ti...\r\n\r\nchau chau chau \r\nmejor me voy no quiero verte ya no voy a volver,\r\nya me canse de ti de tu ironia...\r\nchau chau chau \r\nmejor me voy, no me esperes mas ya no voy a volver\r\nya me canse de tus mentiras...\r\nchau chau chau \r\nmejor me voy no te deseo el mal y que te vaya bien,\r\nyo te olvidare y seguire mi vida.', 2, 1, 'Quiero Amarte', '<iframe width=\"200\" height=\"200\" src=\"https://www.youtube.com/embed/dXnUxRNDXDU\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(3, 'Eres', '02:43', 'Mariano Agostini', 'Eres la mujer que yo sone, yo que siempre te espere,\r\nsin pensar que llegarias...\r\n\r\neres mi ternura y la pasion mi total adoracion, la mujer de mi vida...\r\n\r\nEres mi vida mi gran amor, eres mi sueño eres mi pasion,\r\nyo quiero amarte ti, para amarte mas te entrego mi alma...\r\n\r\nEres mi vida mi gran amor, eres la duena de mi corazon,\r\nyo quiero amarte mas, voy a cuidarte amor toda la vida\r\nno voy a perderte, por que te amo.', 3, 1, 'Quiero Amarte', '<iframe width=\"200\" height=\"200\" src=\"https://www.youtube.com/embed/4tqiRp0G9CI\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(4, 'Hasta el amanecer', '03:53', 'Mariano Agostini', 'Hoy quiero tenerte aqui rendida en mi cama \r\nvoy a darte todo por completo mi corazon,\r\npor que ya no puedo ya no aguanto sin tenerte junto a mi\r\npor que yo de ti, me enamore...\r\n\r\nhoy voy hacerte el amor la noche entera\r\npor que te iras y manana ya no se si volveras\r\nse que voy abrazarte mi amor por la manana\r\ncuidarte a ti el corazon yo siento amor\r\nsolo por ti...\r\n\r\nEs que tu, te quedaras conmigo hasta  amanacer\r\nse que yo me quedare solo extranandote\r\nEs que tu, te quedaras conmigo hasta  amanacer\r\nse que yo me quedare solo aqui amandote hasta amanecer', 4, 1, 'Quiero Amarte', '<iframe width=\"200\" height=\"200\" src=\"https://www.youtube.com/embed/fG6a8VYfP9c\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(5, 'Con el corazon en la mano', '05:02', 'Mariano Agostini', 'Hoy me dices que te vas\r\nque te marchas de mi vida\r\nque es la unica salida\r\ny que tengo que olvidar\r\nque me voy acostumbrar\r\nque de amor nadie se muere\r\ny que la verdad no hiere\r\nque la tengo que aceptar\r\nque facil es hablar asi\r\nque facil es pensar por mi\r\nque facil para quien va a partir\r\ncon el corazon en la mano\r\nhoy vengo a tu despedida\r\nte pido que te lo lleves\r\no quitale aqui la vida\r\ncon el corazon en la mano\r\nhoy vengo a tu despedida\r\nte vas cuando mas te quiero\r\ncomo una desconocida\r\nque no estas para el amor\r\nque ser libre es importante\r\nque hay un mundo por delante\r\ny es mejor para los dos\r\nque me voy acostumbrar\r\nque de amor nadie se muere\r\ny que la verdad no hiere\r\nque la tengo que aceptar\r\nque facil es, hablar asi\r\nque facil es, pensar por mi\r\nque facil para quien va a partir\r\ncon el corazon en la mano\r\nhoy vengo a tu despedida\r\nte pido que te lo lleves\r\no quitale aqui la vida\r\ncon el corazon en la mano\r\nhoy vengo a tu despedida\r\nte vas cuando mas te quiero\r\ncomo una desconocida\r\ncon el corazon en la mano\r\nhoy vengo a tu despedida\r\nte pido que te lo lleves\r\no quitale aqui la vida', 5, 1, 'Quiero Amarte', '<iframe width=\"200\" height=\"200\" src=\"https://www.youtube.com/embed/D83yKuJ_-7k\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `discos`
--

CREATE TABLE `discos` (
  `id_disco` int(11) NOT NULL,
  `cd_nom` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `cd_can` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cd_dur` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cd_anio` int(11) DEFAULT NULL,
  `cd_completo` varchar(500) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cd_gracias` varchar(500) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `discos`
--

INSERT INTO `discos` (`id_disco`, `cd_nom`, `cd_can`, `cd_dur`, `cd_anio`, `cd_completo`, `cd_gracias`) VALUES
(1, 'Quiero Amarte', '12', '38:45', 2019, '<iframe width=\"200\" height=\"200\" src=\"https://www.youtube.com/embed/Nz8UD6aqbmg\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'Gracias');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ineditos`
--

CREATE TABLE `ineditos` (
  `inedito_id` int(11) NOT NULL,
  `inedito_nombre` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `inedito_duracion` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `inedito_video` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `ineditos`
--

INSERT INTO `ineditos` (`inedito_id`, `inedito_nombre`, `inedito_duracion`, `inedito_video`) VALUES
(1, 'Peligro de Extincion', '03:10', '<iframe width=\"300\" height=\"200\" src=\"https://www.youtube.com/embed/BceCxLIbFCs\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notas`
--

CREATE TABLE `notas` (
  `nota_id` int(11) NOT NULL,
  `nota_nombre` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nota_duracion` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nota_video` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `notas`
--

INSERT INTO `notas` (`nota_id`, `nota_nombre`, `nota_duracion`, `nota_video`) VALUES
(1, 'QUE TE PUEDO CONTAR - MARIANO ', '17:48', '<iframe width=\"300\" height=\"200\" src=\"https://www.youtube.com/embed/1lBCudFqOLM\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(2, 'MARIANO AGOSTINI - 26 DE ABRIL', '07:38', '<iframe width=\"300\" height=\"200\" src=\"https://www.youtube.com/embed/y7jx_JHdHCY\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(3, 'MARIANO AGOSTINI - PREMIO CANDELA (2018)', '01:43', '<iframe width=\"300\" height=\"200\" src=\"https://www.youtube.com/embed/m_NvPFL3fpA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `videos`
--

CREATE TABLE `videos` (
  `video_id` int(11) NOT NULL,
  `video_nombre` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL,
  `video_duracion` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `video_url` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `videos`
--

INSERT INTO `videos` (`video_id`, `video_nombre`, `video_duracion`, `video_url`) VALUES
(1, 'MARIANO AGOSTINI | VAMOS A PASARLA BIEN | 2 DE FEBRERO', '04:18', '<iframe width=\"300\" height=\"200\" src=\"https://www.youtube.com/embed/EnLT5n5HrZ0\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(2, 'MARIANO AGOSTINI | EN VIVO | VAMOS A PASARLA BIEN | 2 DE MARZO', '15:46', '<iframe width=\"300\" height=\"200\" src=\"https://www.youtube.com/embed/8CkEKS-G7xQ\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(3, 'MARIANO AGOSTINI | EN VIVO | VAMOS A PASARLA BIEN | 30 DE JUNIO', '15:38', '<iframe width=\"300\" height=\"200\" src=\"https://www.youtube.com/embed/RW5Vna_5WDc\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(4, 'MARIANO AGOSTINI | VAMOS A PASARLA BIEN | 26 DE ENERO', '04:18', '<iframe width=\"300\" height=\"200\" src=\"https://www.youtube.com/embed/GH9l1xG1uVM\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(5, 'VAMOS A PASARLO BIEN | MARIANO AGOSTINI | 17 DE MARZO', '12:21', '<iframe width=\"300\" height=\"200\" src=\"https://www.youtube.com/embed/teQtUWdt8j8\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `canciones`
--
ALTER TABLE `canciones`
  ADD PRIMARY KEY (`track_id`);

--
-- Indices de la tabla `discos`
--
ALTER TABLE `discos`
  ADD PRIMARY KEY (`id_disco`);

--
-- Indices de la tabla `ineditos`
--
ALTER TABLE `ineditos`
  ADD PRIMARY KEY (`inedito_id`);

--
-- Indices de la tabla `notas`
--
ALTER TABLE `notas`
  ADD PRIMARY KEY (`nota_id`);

--
-- Indices de la tabla `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`video_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `canciones`
--
ALTER TABLE `canciones`
  MODIFY `track_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `discos`
--
ALTER TABLE `discos`
  MODIFY `id_disco` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `ineditos`
--
ALTER TABLE `ineditos`
  MODIFY `inedito_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `notas`
--
ALTER TABLE `notas`
  MODIFY `nota_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `videos`
--
ALTER TABLE `videos`
  MODIFY `video_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
