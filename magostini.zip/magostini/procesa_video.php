<?php
include_once "acceso_bd.php";
//include_once "accesso_bd.php"; // Conexion a la Base Hackaton

//Variables Fijas
$respuestaOK = false;
$mensajeError = "No se puede ejecutar la aplicación";
$contenidoOK = "";  

// Recibo 
$id_disco = trim($_POST['disco']);
$id_video = trim($_POST['video']);

	
// Cambio de variables
$mysqli = conexionBD();
$result_cd_diferente = $mysqli->query("SELECT * FROM canciones WHERE id_disco = '".$id_disco."' and track_track = '".$id_video."' ");

while($res = $result_cd_diferente -> fetch_array(MYSQLI_ASSOC))
		{
			$video = $res['c_video'];				
		}

$respuestaOK = true;
$mensajeError = "";
$contenidoOK = $video;

$salidaJson = array("respuesta" => $respuestaOK,
                    "mensaje" => $mensajeError,
                    "contenido" => $contenidoOK );

echo json_encode($salidaJson);   
?>