<?php
include_once "acceso_bd.php"; // Archivo de Conexion
$mysqli = conexionBD(); // Conecta a la BD


$respuestaOK = false;
$mensajeError = "No se puede ejecutar la aplicación";
$contenidoOK = "";  

// Recibimos el Id referente al disco
$variable= $_POST['valorCaja1'];


switch($variable) {
case $variable:

$query_videos = $mysqli->query("SELECT nota_nombre, nota_video FROM notas WHERE nota_id = '".$variable."'  ");
while($res = $query_videos -> fetch_array(MYSQLI_ASSOC))
            {
        $video ='
<div class="card">
  <div class="card-header bg-dark text-white">'.$res['nota_nombre'].'</div>
  <div class="card-body">'.$res['nota_video'].'</div> 

</div>

    ';
                        
            }

$respuestaOK = true;
$mensajeError = "No se puede ejecutar la aplicación";
$contenidoOK = $video; 

break;

default:
echo '$variable no es igual a 1, 2 o 3.';
}



$salidaJson = array("respuesta" => $respuestaOK,
                    "mensaje" => $mensajeError,
                    "contenido" => $contenidoOK);

echo json_encode($salidaJson); 