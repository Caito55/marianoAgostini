<?php //include("discos.php");  ?>
<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" type="text/css" href="css/video.css">
		<script type="text/javascript" src="js/nota.js"></script>
</head>



<!-- VIDEOS -->
  <div class="card" style="width:auto" align="center">
    <img class="card-img-top" src="image/notas.jfif"  style="width:100%">
    <div class="card-body">
      <h4 class="card-title">NOTAS</h4><hr>
      <p class="card-text"></p>
      <!--<a href="#video" class="btn btn-primary btn-block" data-toggle="collapse">Videos</a>-->

      <!-- VIDEO DE LA ENTREVISTA -->
            <div id="muestra_notas" class="collapse"> 
                <!--<button id="cerrar_tema" class="btn btn-info btn-block hidden">Ineditos</button>-->
                <div id="vernota"></div>
            </div>
      <!-- VIDEO DE LA ENTREVISTA -->      

    <!-- TABLA NOTAS -->
      <table class="table " cellpadding="0" cellspacing="0" border="0" width="auto" id="listanotas">
          <thead>
             <tr>
               <th>Nº</th>
               <th>Nombre</th>
               <th>Reproducir</th>
             </tr>
          </thead>
           <tbody>
               <?php echo ver_notas(); ?>
         </tbody>               
      </table>    
    <!-- TABLA NOTAS -->



    </div>
  </div> <br>
<!-- VIDEOS -->
	
  
  
  <!--<div id="video" class="collapse">-->
  <div id="notas">	


  </div>

 

<?php
    function ver_notas(){
        $salida = "";
        $mysqli = conexionBD();
        $contenido_notas = $mysqli->query("SELECT * FROM notas ");
        while($row_i = $contenido_notas -> fetch_array(MYSQLI_ASSOC))
        {            

            $salida.='
                  <tr>
                    <td><small>'.$row_i['nota_id'].'</small></td>
                    <td><small>'.$row_i['nota_nombre'].'</small>

                    </td>
                    <td>
                    <a  tema="'.$row_i['nota_id'].'" id="abrir_nota" data-toggle="collapse" data-target="#muestra_notas">
                    <small> <img src="image/play.png" width="30" height="30" alt="Play" /> 
                    </small></a>
                    </td>
                  </tr>
               

                ';
            } // Cierra While
            return $salida;

        }// Cierra funcion ii
?>