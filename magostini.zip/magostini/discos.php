<?php
include("acceso_bd.php");


   function diferente(){
        $resp_diferente= "";

          $mysqli = conexionBD(); // Conexion a la Base Hackaton
          $disco_diferente = $mysqli->query("SELECT * FROM discos  WHERE id_disco = 1 ");   
         
            while($res_ver = $disco_diferente -> fetch_array(MYSQLI_ASSOC))
            {
                $agradecimientos = $res_ver['cd_gracias'];
                $nombredisco  = $res_ver['cd_nom'];


        // CHAU CHAU CHAU
        $contenido_track1_diferente = $mysqli->query("SELECT * FROM canciones where id_disco = 1 and track_track = 1");
        while($row_diferente1 = $contenido_track1_diferente -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_diferente1 = $row_diferente1['track_track'];
            $letra_diferente_1 = $row_diferente1['track_letra'];
            $c_nombre_diferente1 = $row_diferente1['track_nombre'];
            $c_duracion_diferente1 = $row_diferente1['track_duracion'];
            $c_colaborador_diferente1 = $row_diferente1['track_colaborador'];
            //$c_video_verdadero1 = $row_verdadero1['c_video'];
        }  

        $contenido_track2_diferente = $mysqli->query("SELECT * FROM canciones where id_disco = 1 and track_track = 2");
        while($row_diferente2 = $contenido_track2_diferente -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_diferente2 = $row_diferente2['track_track'];
            $letra_diferente_2 = $row_diferente2['track_letra'];
            $c_nombre_diferente2 = $row_diferente2['track_nombre'];
            $c_duracion_diferente2 = $row_diferente2['track_duracion'];
            $c_colaborador_diferente2 = $row_diferente2['track_colaborador'];
            //$c_video_verdadero1 = $row_verdadero1['c_video'];
        }  

        $contenido_track3_diferente = $mysqli->query("SELECT * FROM canciones where id_disco = 1 and track_track = 3");
        while($row_diferente3 = $contenido_track3_diferente -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_diferente3 = $row_diferente3['track_track'];
            $letra_diferente_3 = $row_diferente3['track_letra'];
            $c_nombre_diferente3 = $row_diferente3['track_nombre'];
            $c_duracion_diferente3 = $row_diferente3['track_duracion'];
            $c_colaborador_diferente3 = $row_diferente3['track_colaborador'];
            //$c_video_verdadero1 = $row_verdadero1['c_video'];
        } 

        $contenido_track4_diferente = $mysqli->query("SELECT * FROM canciones where id_disco = 1 and track_track = 4");
        while($row_diferente4 = $contenido_track4_diferente -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_diferente4 = $row_diferente4['track_track'];
            $letra_diferente_4 = $row_diferente4['track_letra'];
            $c_nombre_diferente4 = $row_diferente4['track_nombre'];
            $c_duracion_diferente4 = $row_diferente4['track_duracion'];
            $c_colaborador_diferente4 = $row_diferente4['track_colaborador'];
            //$c_video_verdadero1 = $row_verdadero1['c_video'];
        } 

        $contenido_track5_diferente = $mysqli->query("SELECT * FROM canciones where id_disco = 1 and track_track = 5");
        while($row_diferente5 = $contenido_track5_diferente -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_diferente5 = $row_diferente5['track_track'];
            $letra_diferente_5 = $row_diferente5['track_letra'];
            $c_nombre_diferente5 = $row_diferente5['track_nombre'];
            $c_duracion_diferente5 = $row_diferente5['track_duracion'];
            $c_colaborador_diferente5 = $row_diferente5['track_colaborador'];
            //$c_video_verdadero1 = $row_verdadero1['c_video'];
        } 
/*        
        $contenido_track6_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 6");
        while($row_verdadero6 = $contenido_track6_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero6 = $row_verdadero6['c_track'];
            $letra_verdadero_6 = $row_verdadero6['c_letra'];
            $c_nombre_verdadero6 = $row_verdadero6['c_nombre'];
            $c_duracion_verdadero6 = $row_verdadero6['c_duracion'];
            $c_colaborador_verdadero6 = $row_verdadero6['c_colaborador'];
            //$c_video_verdadero6 = $row_verdadero6['c_video'];
        }  

        $contenido_track7_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 7");
        while($row_verdadero7 = $contenido_track7_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero7 = $row_verdadero7['c_track'];
            $letra_verdadero_7 = $row_verdadero7['c_letra'];
            $c_nombre_verdadero7 = $row_verdadero7['c_nombre'];
            $c_duracion_verdadero7 = $row_verdadero7['c_duracion'];
            $c_colaborador_verdadero7 = $row_verdadero7['c_colaborador'];
            //$c_video_verdadero7 = $row_verdadero7['c_video'];
        }  

        $contenido_track8_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 8");
        while($row_verdadero8 = $contenido_track8_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero8 = $row_verdadero8['c_track'];
            $letra_verdadero_8 = $row_verdadero8['c_letra'];
            $c_nombre_verdadero8 = $row_verdadero8['c_nombre'];
            $c_duracion_verdadero8 = $row_verdadero8['c_duracion'];
            $c_colaborador_verdadero8 = $row_verdadero8['c_colaborador'];
            //$c_video_verdadero8 = $row_verdadero8['c_video'];
        }  

        $contenido_track9_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 9");
        while($row_verdadero9 = $contenido_track9_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero9 = $row_verdadero9['c_track'];
            $letra_verdadero_9 = $row_verdadero9['c_letra'];
            $c_nombre_verdadero9 = $row_verdadero9['c_nombre'];
            $c_duracion_verdadero9 = $row_verdadero9['c_duracion'];
            $c_colaborador_verdadero9 = $row_verdadero9['c_colaborador'];
            //$c_video_verdadero9 = $row_verdadero9['c_video'];
        }  

        $contenido_track10_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 10");
        while($row_verdadero10 = $contenido_track10_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero10 = $row_verdadero10['c_track'];
            $letra_verdadero_10 = $row_verdadero10['c_letra'];
            $c_nombre_verdadero10 = $row_verdadero10['c_nombre'];
            $c_duracion_verdadero10 = $row_verdadero10['c_duracion'];
            $c_colaborador_verdadero10 = $row_verdadero10['c_colaborador'];
            //$c_video_verdadero10 = $row_verdadero10['c_video'];
        }  

        $contenido_track11_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 11");
        while($row_verdadero11 = $contenido_track11_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero11 = $row_verdadero11['c_track'];
            $letra_verdadero_11 = $row_verdadero11['c_letra'];
            $c_nombre_verdadero11 = $row_verdadero11['c_nombre'];
            $c_duracion_verdadero11 = $row_verdadero11['c_duracion'];
            $c_colaborador_verdadero11 = $row_verdadero11['c_colaborador'];
            //$c_video_verdadero11 = $row_verdadero11['c_video'];
        }  

        $contenido_track12_verdadero = $mysqli->query("SELECT * FROM canciones where id_disco = 8 and c_track = 12");
        while($row_verdadero12 = $contenido_track12_verdadero -> fetch_array(MYSQLI_ASSOC))
        {            
            $cd_track_verdadero12 = $row_verdadero12['c_track'];
            $letra_verdadero_12 = $row_verdadero12['c_letra'];
            $c_nombre_verdadero12 = $row_verdadero12['c_nombre'];
            $c_duracion_verdadero12 = $row_verdadero12['c_duracion'];
            $c_colaborador_verdadero12 = $row_verdadero12['c_colaborador'];
            //$c_video_verdadero12= $row_verdadero12['c_video'];
        }                                                                                          
*/
        //$resp_diferente .=' '.$cd_track_diferente1.'  ';

 $resp_diferente .='
  <!-- Nav tabs -->
  <ul class="nav nav-tabs">

    <li class="nav-item">
      <a class="nav-link active" data-toggle="tab" href="#home">Inicio</a>
    </li>

    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#cd">CD</a>
    </li>

  </ul>
  <!-- Nav tabs -->

  <!-- Tab panes -->
  <div class="tab-content">
    <div id="home" class="container tab-pane active"><br>
      <h3>AGRADECIMIENTOS</h3>
      <p>Agradecimientos del CD.</p>
    </div>
    <div id="cd" class="container tab-pane fade"><br>
      <h3>Quiero Amarte (2018)</h3>
      
      <h3>Lista de canciones</h3>
                          
        
      <!--<h4>Mariano Agostini</h4><br>-->


 </small></p><br>
        <table class="table table-condensed">
          <thead>
            <tr>
              <th>Track</th>
              <th>Nombre de la cancion</th>
            </tr>
          </thead>
          <tbody>
          
          <!-- TEMA 1 QUIERO AMARTE -->
          <tr>
              <td>'.$cd_track_diferente1.'</td>
              <td>'.$c_nombre_diferente1.'

             <a href="#sim" id="tema_chau_1" data-toggle="collapse" data-target="#track_chau" ><small> <img src="image/play.png" width="30" height="30" alt="Play" /> </small></a> | 

             <a href="#ver_cdsolo" id="dc_sim" data-toggle="collapse" data-target="#apartirl" ><small> <img src="image/Letra.png" width="30" height="30" alt="Letra" /> </small></a>

	        <!-- FORMULARIO PARA IFRAME -->     
			<form id="cd_diferente_track_1">
			    <input id="id_disco" name="disco" value="1" class="d-none">
			    <input id="id_video" name="video" value="1" class="d-none">
			</form>
			<!-- FORMULARIO PARA IFRAME -->   

	        <!-- VIDEO --><br>
	        <div id="track_chau" class="col-xs-12 collapse">                                  
	        <!-- ACA VA EL VIDEO -->

	        </div>
	        <!-- VIDEO -->

	        <!-- LETRA  -->
	        <div id="apartirl" class="col-xs-12 collapse"><br>
	        <table class="table table-condensed">
	            <thead>
	                <tr>
	                   <th><h3>'.$c_nombre_diferente1.' <small> <br>Duracion: <b>'.$c_duracion_diferente1.'
	                   </b></small></h3><small>'.$c_colaborador_diferente1.'</small></th>
	                </tr>
	            </thead>
	            <tbody>
	                <tr>
	                    <td>
						<p><small>
						Es una pena que no quieras ya de mis caricias,
						por qué te amaba con el alma entera y con mi corazón,
						yo que soñaba regalarte siempre cada primavera 
						un poema una rosa una carta y una canción,
						<br><br>
						Ahora que ya no te tengo me quede tan solo y triste,
						pensando quien te besará quien te hará el amor,
						No me avergüenza decir que te extraño por las madrugadas
						y que me cuesta despertar sin ti sin sentir tu calor...
						me haces falta amor 
						<br><br>

						<b>ESTRIBILLO:</b><br>
						¡Ay!  quiero amarte
						y que mi corazón no sufra ya por tu amor
						y acariciarte, que me llenes de ternura y de pasión.
						</small>
						</p>
	                    </td>
	                </tr>
	            </tbody>
	        </table>
	        </div>
	        <!-- LETRA  -->

	           </td>
	        </tr> 
	        <!-- TEMA 1 QUIERO AMARTE -->  




  <!-- TEMA 2 CHAU CHAU CHAU-->
          <tr>
              <td>'.$cd_track_diferente2.'</td>
              <td>'.$c_nombre_diferente2.'

             <a href="#sim" id="tema_chau_2" data-toggle="collapse" data-target="#track_chau2" ><small> <img src="image/play.png" width="30" height="30" alt="Play" /> </small></a> | 
             <a href="#ver_cdsolo" id="dc_sim" data-toggle="collapse" data-target="#letra_chau" ><small> <img src="image/Letra.png" width="30" height="30" alt="Letra" /> </small></a>

	        <!-- FORMULARIO PARA IFRAME -->     
			<form id="cd_diferente_track_2">
			    <input id="id_disco" name="disco" value="1" class="d-none">
			    <input id="id_video" name="video" value="2" class="d-none">
			</form>
			<!-- FORMULARIO PARA IFRAME -->   

	        <!-- VIDEO --><br>
	        <div id="track_chau2" class="col-xs-12 collapse">                                  
	        <!-- ACA VA EL VIDEO -->

	        </div>
	        <!-- VIDEO -->

	        <!-- LETRA  -->
	        <div id="letra_chau" class="col-xs-12 collapse"><br>
	        <table class="table table-condensed">
	            <thead>
	                <tr>
	                   <th><h3>'.$c_nombre_diferente2.' <small> <br>Duracion: <b>'.$c_duracion_diferente2.'
	                   </b></small></h3><small>'.$c_colaborador_diferente2.'</small></th>
	                </tr>
	            </thead>
	            <tbody>
	                <tr>
	                    <td>
						<p><small>
						Ya no quiero ser tu amigo, tampoco quiero ser tu amor,
						ya no quiero más ni verte, nuestra historia termino,
						ya me cansé de tus mentiras por eso ahora yo me voy,
						sabías que yo te quería, pero eso nunca te importo,
						por eso yo me voy lejos de ti...
						<br><br>

						<b>ESTRIBILLO</b><br>
						chau chau chau 
						mejor me voy no quiero verte ya no voy a volver,
						ya me cansé de ti de tu ironía...
						<br><br>
						chau chau chau 
						mejor me voy, no me esperes mas ya no voy a volver
						ya me cansé de tus mentiras...
						<br><br>
						chau chau chau 
						mejor me voy no te deseo el mal y que te vaya bien,
						yo te olvidare y seguiré mi vida.
						</small>
						</p>

	                    </td>
	                </tr>
	            </tbody>
	        </table>
	        </div>
	        <!-- LETRA  -->

	           </td>
	        </tr> 
	        <!-- TEMA 2 CHAU CHAU CHAU -->  	        




  <!-- TEMA 3 ERES-->
          <tr>
              <td>'.$cd_track_diferente3.'</td>
              <td>'.$c_nombre_diferente3.'

             <a href="#sim" id="tema_eres_3" data-toggle="collapse" data-target="#track_eres3" ><small> <img src="image/play.png" width="30" height="30" alt="Play" /> </small></a> | 

             <a href="#ver_cdsolo" id="dc_sim" data-toggle="collapse" data-target="#letra_eres"> <small> <img src="image/Letra.png" width="30" height="30" alt="Letra" /> </small></a>

	        <!-- FORMULARIO PARA IFRAME -->     
			<form id="cd_diferente_track_3">
			    <input id="id_disco" name="disco" value="1" class="d-none">
			    <input id="id_video" name="video" value="3" class="d-none">
			</form>
			<!-- FORMULARIO PARA IFRAME -->   

	        <!-- VIDEO --><br>
	        <div id="track_eres3" class="col-xs-12 collapse">                                  
	        <!-- ACA VA EL VIDEO -->

	        </div>
	        <!-- VIDEO -->

	        <!-- LETRA  -->
	        <div id="letra_eres" class="col-xs-12 collapse"><br>
	        <table class="table table-condensed">
	            <thead>
	                <tr>
	                   <th><h3>'.$c_nombre_diferente3.' <small> <br>Duracion: <b>'.$c_duracion_diferente3.'
	                   </b></small></h3><small>'.$c_colaborador_diferente3.'</small></th>
	                </tr>
	            </thead>
	            <tbody>
	                <tr>
	                    <td>
						<p><small>
						Eres la mujer que yo soñé, yo que siempre te esperé,
						sin pensar que llegarías...
						eres mi ternura y la pasión mi total adoración, 
						la mujer de mi vida...
						<br><br>

						<b>ESTRIBILLO:</b><br><br>
						Eres mi vida mi gran amor, eres mi sueño eres mi pasión,
						yo quiero amarte ti, para amarte más te entrego mi alma...
						<br><br>

						Eres mi vida mi gran amor, eres la dueña de mi corazón,
						yo quiero amarte más, voy a cuidarte amor toda la vida
						no voy a perderte, porque te amo.
						</small>
						</p>
	                    </td>
	                </tr>
	            </tbody>
	        </table>
	        </div>
	        <!-- LETRA  -->

	           </td>
	        </tr> 
	        <!-- TEMA 3 ERES -->  		


  <!-- TEMA 4 HASTA EL AMANECER -->
          <tr>
              <td>'.$cd_track_diferente4.'</td>
              <td>'.$c_nombre_diferente4.'

             <a href="#sim" id="tema_amanecer_4" data-toggle="collapse" data-target="#track_amanecer4"><small> <img src="image/play.png" width="30" height="30" alt="Play" /> </small></a> | 
             <a href="#ver_cdsolo" id="dc_sim" data-toggle="collapse" data-target="#letra_amanecer" ><small> <img src="image/Letra.png" width="30" height="30" alt="Letra" /> </small></a>

	        <!-- FORMULARIO PARA IFRAME -->     
			<form id="cd_diferente_track_4">
			    <input id="id_disco" name="disco" value="1" class="d-none">
			    <input id="id_video" name="video" value="4" class="d-none">
			</form>
			<!-- FORMULARIO PARA IFRAME -->   

	        <!-- VIDEO --><br>
	        <div id="track_amanecer4" class="col-xs-12 collapse">                                  
	        <!-- ACA VA EL VIDEO -->

	        </div>
	        <!-- VIDEO -->

	        <!-- LETRA  -->
	        <div id="letra_amanecer" class="col-xs-12 collapse"><br>
	        <table class="table table-condensed">
	            <thead>
	                <tr>
	                   <th><h3>'.$c_nombre_diferente4.' <small> <br>Duracion: <b>'.$c_duracion_diferente4.'
	                   </b></small></h3><small>'.$c_colaborador_diferente4.'</small></th>
	                </tr>
	            </thead>
	            <tbody>
	                <tr>
	                    <td>
					<p><small>
					Hoy quiero tenerte aquí rendida en mi cama 
					voy a darte todo por completo mi corazón,
					porque ya no puedo ya no aguanto sin tenerte junto a mi
					porque yo de ti, me enamore...
					<br><br>

					hoy voy hacerte el amor la noche entera
					porque te iras y mañana ya no sé si volverás
					sé que voy abrazarte mi amor por la mañana
					cuidarte a ti el corazón yo siento amor
					solo por ti...
					<br><br>

					<b>ESTRIBILLO:</b><br><br>
					Es que tú, te quedaras conmigo hasta amanecer
					sé que yo me quedare solo extrañándote
					Es que tú, te quedaras conmigo hasta  amanecer
					sé que yo me quedare solo aquí amándote hasta amanecer.
					</small>
					</p>
	                    </td>
	                </tr>
	            </tbody>
	        </table>
	        </div>
	        <!-- LETRA  -->

	           </td>
	        </tr> 
	        <!-- TEMA 4 HASTA EL AMANECER  -->  		        

	                                                                                                           
  <!-- TEMA 5 CON EL CORAZON EN LA MANO -->
          <tr>
              <td>'.$cd_track_diferente5.'</td>
              <td>'.$c_nombre_diferente5.'

             <a href="#sim" id="tema_corazon_5" data-toggle="collapse" data-target="#track_corazon5"><small> <img src="image/play.png" width="30" height="30" alt="Play" /> </small></a> | 

             <a href="#ver_cdsolo" id="dc_sim" data-toggle="collapse" data-target="#letra_corazon" ><small> <img src="image/Letra.png" width="30" height="30" alt="Letra" /> </small></a>

	        <!-- FORMULARIO PARA IFRAME -->     
			<form id="cd_diferente_track_5">
			    <input id="id_disco" name="disco" value="1" class="d-none">
			    <input id="id_video" name="video" value="5" class="d-none">
			</form>
			<!-- FORMULARIO PARA IFRAME -->   

	        <!-- VIDEO --><br>
	        <div id="track_corazon5" class="col-xs-12 collapse">                                  
	        <!-- ACA VA EL VIDEO -->

	        </div>
	        <!-- VIDEO -->

	        <!-- LETRA  -->
	        <div id="letra_corazon" class="col-xs-12 collapse"><br>
	        <table class="table table-condensed">
	            <thead>
	                <tr>
	                   <th><h3>'.$c_nombre_diferente5.' <small> <br>Duracion: <b>'.$c_duracion_diferente5.'
	                   </b></small></h3><small>'.$c_colaborador_diferente5.'</small></th>
	                </tr>
	            </thead>
	            <tbody>
	                <tr>
	                    <td>
					<p><small>
					Hoy me dices que te vas
					que te marchas de mi vida
					que es la única salida
					y que tengo que olvidar
					<br><br>

					que me voy acostumbrar
					que de amor nadie se muere
					y que la verdad no hiere
					que la tengo que aceptar
					<br><br>

					que fácil es hablar así
					que fácil es pensar por mí
					que fácil para quien va a partir
					<br><br>

					con el corazón en la mano
					hoy vengo a tu despedida
					te pido que te lo lleves
					o quítale aquí la vida
					<br><br>

					<b>ESTRIBILLO:</b><br><br>
					Con el corazón en la mano
					hoy vengo a tu despedida
					te vas cuando más te quiero
					como una desconocida
					<br><br>

					que no estas para el amor
					que ser libre es importante
					que hay un mundo por delante
					y es mejor para los dos
					<br><br>

					que me voy acostumbrar
					que de amor nadie se muere
					y que la verdad no hiere
					que la tengo que aceptar
					<br><br>

					que fácil es, hablar así
					que fácil es, pensar por mí
					que fácil…

					</small>
					</p>
	                    </td>
	                </tr>
	            </tbody>
	        </table>
	        </div>
	        <!-- LETRA  -->

	           </td>
	        </tr> 
	        <!-- TEMA 5 CON EL CORAZON EN LA MANO -->  	


	            </tbody>
	           </table>
	        </div>
	        </td>
	        </tr>

	          </tbody>
	          </table>
	          </div> <!-- Cierra CD -->                           


    </div>

  </div>
              ';
          }
    return $resp_diferente;          
    }           

?>