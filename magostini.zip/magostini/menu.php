<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Mariano Agostini</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar" id="idmenu">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#" id="discografia">DISCOGRAFIA</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#" id="show">PRESENTACIONES</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="#" id="videos">VIDEOS</a>
      </li> 

     <li class="nav-item">
        <a class="nav-link" href="#" id="notas">NOTAS</a>
      </li>     

     <li class="nav-item">
        <a class="nav-link" href="#" id="ineditos">CANCIONES INEDITAS</a>
      </li>             
      
    </ul>
  </div> 
</nav>