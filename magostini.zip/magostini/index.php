<?php 
//include("discos.php"); 
?>


<!DOCTYPE html>
<html>
	<head>
		<title>Mariano Agostini</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />


		<script type="text/javascript" src="https://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script> <!-- IE Interprete MQueries -->


  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">  
  		<link rel="stylesheet" type="text/css" href="css/index.css">	
  		<link rel="stylesheet" type="text/css" href="css/cd.css">	
  		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  		<link href="navbar-fixed-top.css" rel="stylesheet">
		<!--<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">-->
		<!--<link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">-->

  		
  		<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->  		
  			
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>		

  		<!-- <script type="text/javascript" src="js/fn.js"></script> -->
  		<script type="text/javascript" src="js/menu.js"></script>

  		<!--<script type="text/javascript" src="js/fn.js"></script>-->


<script type="text/javascript">
	//Codigo jquery	
</script>

	</head>
	<body>

		<?php include('menu.php'); ?>
		<br><br><br>
			
			<!--
			<div class="well" id="title">
				<h2 id="titulo">MARIANO AGOSTINI</h2>
				<h2 id="discografia" class="d-none">DISCOGRAFIA</h2>
			</div>
			-->
	
		<div class="content-fluid" id="contenido">	
			<?php  include('cd1.php'); ?> 
		</div>

		<div class="content-fluid d-none" id="contenido_show" align="center">
			<?php //include('cd1.php'); ?> 
		</div>

		<div class="content-fluid d-none" id="contenido_videos" align="center">
			<?php include('videos.php'); ?> 
		</div>		

		<div class="content-fluid d-none" id="contenido_notas" align="center">
			<?php include('notas.php'); ?> 
		</div>	

		<div class="content-fluid d-none" id="contenido_ineditos" align="center">
			<?php include('ineditos.php'); ?> 
		</div>	

	</div>	

	</body>
</html>
