<?php //include("discos.php");  ?>
<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<script type="text/javascript" src="js/inedito.js"></script>
</head>



<!-- VIDEOS -->
  <div class="card col-xs-12" style="width:auto" align="center">
    <img class="card-img-top" src="image/inedito.png" style="width:100%" > <!--style="width:100%"-->
    <div class="card-body">
      <h4 class="card-title">CANCIONES INÉDITAS</h4><hr>
      <p class="card-text"></p>
      <!--<a href="#video" class="btn btn-primary btn-block" data-toggle="collapse">Videos</a>-->

      <!-- VIDEO DE LA ENTREVISTA -->
            <div id="muestra_ineditos" class="collapse"> 
                <!--<button id="cerrar_tema" class="btn btn-info btn-block hidden">Ineditos</button>-->
                <div id="verineditos"></div>
            </div>
      <!-- VIDEO DE LA ENTREVISTA -->      

    <!-- TABLA NOTAS -->
      <table class="table " cellpadding="0" cellspacing="0" border="0" width="auto" id="listaineditos">
          <thead>
             <tr>
               <th>Track</th>
               <th>Nombre</th>
               <th>Reproducir</th>
             </tr>
          </thead>
           <tbody>
               <?php echo ver_inedito(); ?>
         </tbody>               
      </table>    
    <!-- TABLA NOTAS -->



    </div>
  </div> <br>
<!-- VIDEOS -->
	
  
  
  <!--<div id="video" class="collapse">-->
  <div id="notas">	


  </div>



<?php
    function ver_inedito(){
        $salida = "";
        $mysqli = conexionBD();
        $contenido_notas = $mysqli->query("SELECT * FROM ineditos ");
        while($row_i = $contenido_notas -> fetch_array(MYSQLI_ASSOC))
        {            

            $salida.='
                  <tr>
                    <td><small>'.$row_i['inedito_id'].'</small></td>
                    <td><small>'.$row_i['inedito_nombre'].'</small>

                    </td>
                    <td>
                    <a  tema="'.$row_i['inedito_id'].'" id="abrir_nota" data-toggle="collapse" data-target="#muestra_ineditos">
                    <small> <img src="image/play.png" width="30" height="30" alt="Play" /> 
                    </small></a>
                    </td>
                  </tr>
               

                ';
            } // Cierra While
            return $salida;

        }// Cierra funcion ii
?>