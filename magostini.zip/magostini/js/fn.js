$(document).ready(function(){

	$("#btn-cd1").click(function(){		
		//$("#cont_cd1").empty();
		//$("#btn-cd1").hide();
		$("#cont_cd1").fadeIn('1000')
		$("#btn-cd1").addClass('d-none');
		$("#btn-cd1_cerrar").removeClass('d-none');

		var string = $("#cd_diferente").serialize();		
		
                $.ajax({
                cache: false,
                type: "POST",            
                dataType: 'json', 
                url: "funciones/funciones.php", 
                data: string,                                
                 beforeSend: function () { 
                 	//$("#cont_cd1").html("<div class='spinner-border text-primary'></div>");                                            
                    },
                success: function(response) {
                	//alert("adentro");
                	
                    if(response.respuesta == true){       
                 			//alert("dentro del success");
                            $("#cont_cd1").html(response.contenido); // Agrega el Video


                            }

                } // Cierra Success
             }); //cierra AJAX

		//$("#cont_cd1").html("Contenido");
	});

$("#btn-cd1_cerrar").click(function(){
	$("#btn-cd1_cerrar").addClass('d-none');
	$("#btn-cd1").removeClass('d-none');
	$("#cont_cd1").fadeOut('1000');	
});




////////////////////////////
/// DISCO QUIERO AMARTE ////////
////////////////////////////

// CD QUIERO AMARTE TEMA 1
    $("#tema_chau_1").click(function(){

        var string = $("#cd_diferente_track_1").serialize();       

                $.ajax({
                cache: false,
                type: "POST",            
                dataType: 'json', 
                url: "procesa_video.php", 
                data: string,                                
                 beforeSend: function () {                                             
                    },
                success: function(response) {

                    if(response.respuesta == true){       
                 
                            $("#track_chau").html(response.contenido); // Agrega el Video

                            }

                } // Cierra Success
             }); //cierra AJAX
        
    }); // Cierra Click boton abrir escuchar tema   


// CD QUIERO AMARTE TEMA 2  CHAU CHAU CHAU
    $("#tema_chau_2").click(function(){

        var string = $("#cd_diferente_track_2").serialize();       

                $.ajax({
                cache: false,
                type: "POST",            
                dataType: 'json', 
                url: "procesa_video.php", 
                data: string,                                
                 beforeSend: function () {                                             
                    },
                success: function(response) {

                    if(response.respuesta == true){       
                 
                            $("#track_chau2").html(response.contenido); // Agrega el Video

                            }

                } // Cierra Success
             }); //cierra AJAX
        
    }); // Cierra Click boton abrir escuchar tema   



// CD QUIERO AMARTE TEMA 3 ERES
    $("#tema_eres_3").click(function(){

        var string = $("#cd_diferente_track_3").serialize();       

                $.ajax({
                cache: false,
                type: "POST",            
                dataType: 'json', 
                url: "procesa_video.php", 
                data: string,                                
                 beforeSend: function () {                                             
                    },
                success: function(response) {

                    if(response.respuesta == true){       
                 
                            $("#track_eres3").html(response.contenido); // Agrega el Video

                            }

                } // Cierra Success
             }); //cierra AJAX
        
    }); // Cierra Click boton abrir escuchar tema   


// CD QUIERO AMARTE TEMA 4 HASTA EL AMANECER
    $("#tema_amanecer_4").click(function(){

        var string = $("#cd_diferente_track_4").serialize();       

                $.ajax({
                cache: false,
                type: "POST",            
                dataType: 'json', 
                url: "procesa_video.php", 
                data: string,                                
                 beforeSend: function () {                                             
                    },
                success: function(response) {

                    if(response.respuesta == true){       
                 
                            $("#track_amanecer4").html(response.contenido); // Agrega el Video

                            }

                } // Cierra Success
             }); //cierra AJAX
        
    }); // Cierra Click boton abrir escuchar tema   


// CD QUIERO AMARTE TEMA 5 CON EL CORAZON EN LA MANO
    $("#tema_corazon_5").click(function(){

        var string = $("#cd_diferente_track_5").serialize();       

                $.ajax({
                cache: false,
                type: "POST",            
                dataType: 'json', 
                url: "procesa_video.php", 
                data: string,                                
                 beforeSend: function () {                                             
                    },
                success: function(response) {

                    if(response.respuesta == true){       
                 
                            $("#track_corazon5").html(response.contenido); // Agrega el Video

                            }

                } // Cierra Success
             }); //cierra AJAX
        
    }); // Cierra Click boton abrir escuchar tema   


}); // Cierra Document ready