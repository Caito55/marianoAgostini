$(document).ready(function(){


/* 11-06-2019 VIDEOS */
$('body').on('click','#listaineditos a',function (e){
            e.preventDefault();

            // alert($(this).attr('data-accion'));
            // Id Usuario
            id_inedito = $(this).attr('tema');
             var parametros = {
                "valorCaja1" : id_inedito
                             };
            //alert(id_video);

     $.ajax({
                cache: false,
                type: "POST",            
                dataType: 'json', 
                url: "procesa_ver_inedito.php", 
                data: parametros,                                
                 beforeSend: function () {                                             
                    },
                success: function(response) {

                    if(response.respuesta == true)
                    {                         
                        $('#verineditos').html(response.contenido); // Agrega el Video

                    }

                } // Cierra Success
             }); //cierra AJAX            
            
});
/* 11-06-2019 VIDEOS */


});