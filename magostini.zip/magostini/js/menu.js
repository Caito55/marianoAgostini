$(document).ready(function(){

		$("#idmenu").click(function(){
			$("#collapsibleNavbar").slideToggle();
		});

		$("#show").click(function(){
				//$("#contenido").empty();
				$("#contenido").addClass('d-none');
				$("#contenido_videos").addClass('d-none');
				$("#contenido_notas").addClass('d-none');
				$("#contenido_ineditos").addClass('d-none'); 
				$("#contenido_show").removeClass('d-none');		
				$("#collapsibleNavbar").slideToggle();				

		});

		$("#discografia").click(function(){
				//$("#contenido").empty();	

				//$("#collapsibleNavbar").slideToggle();
				$("#contenido_show").addClass('d-none');
				$("#contenido_videos").addClass('d-none');
				$("#contenido_notas").addClass('d-none');
				$("#contenido_ineditos").addClass('d-none'); 
				$("#contenido").removeClass('d-none');
				//$("#contenido").load('cd1.php');		
				//$("#cd_1").load('cd1.php');	
				//$("#cd_1").removeClass('d-none');
				//</div>
		});	

		$("#videos").click(function(){
			$("#collapsibleNavbar").slideToggle();
			$("#contenido").addClass('d-none'); // Oculta discografia
			$("#contenido_show").addClass('d-none'); // Oculta Shows
			$("#contenido_notas").addClass('d-none');
			$("#contenido_ineditos").addClass('d-none'); 
			$("#contenido_videos").removeClass('d-none'); // Muestra Contenido Videos
			
		});

		$("#notas").click(function(){
			$("#collapsibleNavbar").slideToggle();
			$("#contenido").addClass('d-none'); // Oculta discografia
			$("#contenido_show").addClass('d-none'); // Oculta Shows
			$("#contenido_videos").addClass('d-none'); // Oculta Contenido Videos
			$("#contenido_ineditos").addClass('d-none'); 
			$("#contenido_notas").removeClass('d-none'); // Muestra Notas
		});		

		$("#ineditos").click(function(){
			$("#collapsibleNavbar").slideToggle();
			$("#contenido").addClass('d-none'); // Oculta discografia
			$("#contenido_show").addClass('d-none'); // Oculta Shows
			$("#contenido_videos").addClass('d-none'); // Oculta Contenido Videos
			$("#contenido_notas").addClass('d-none'); // Oculta Notas
			$("#contenido_ineditos").removeClass('d-none'); // Muestra ineditos
		});				

}); // DOCUMENT READY