<?php include("discos.php");  ?>
<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<script type="text/javascript" src="js/fn.js"></script>
</head>


		<!-- CD QUIERO AMARTE -->	
		<div class="card " style="width:500px" id="cd_diferente">
		  <img class="card-img-top img-thumbnail cd" src="image/CD1.png" alt="Card image">
		 
		  <div class="card-body cd_down" align="center">
		    <h4 class="card-title">Mariano Agostini <span class="badge badge-secondary">2018</span></h4>


		    <p class="card-text" align="center">
    		<!-- YOUTUBE -->
		    <a title="marianoagostini_ok" href="https://www.youtube.com/channel/UCdLSZAwBB-o6k70Uocq7CSg"><img src="image/youtube.png" width="30" height="30" alt="Mariano Agostini Ok. Oficial" /></a>
		    <!-- YOUTUBE -->


		    <!-- SPOFITY -->
		    <a title="marianoagostini_ok" href="https://open.spotify.com/search/results/Mariano%20agostini"><img src="image/sp.png" width="30" height="30" alt="Mariano Agostini" /></a>
		    <!-- SPOFITY -->

		    <strong># Quiero Amarte</strong>
		    
		    <!-- INSTAGRAM -->
		    <a title="marianoagostini_ok" href="https://www.instagram.com/marianoagostini_ok/?hl=es-la"><img src="image/instagram.png" width="40" height="40" alt="Los Tejos" /></a> 
		    <!-- INSTAGRAM -->

		    <!-- FACEBOOK -->
		    <a title="marianoagostini_ok" href="https://www.facebook.com/MarianoAgostiniPaginaOficial/"><img src="image/facebook.png" width="35" height="35" alt="Los Tejos" /></a>
		    <!-- FACEBOOK -->


		    </p>

		      <a href="#cont_cd1" id="btn-cd1" data-toggle="collapse" data-target="#cont_cd1" class="btn btn-info  btn-block">Abrir Disco</a>  

		      <a href="#" id="btn-cd1_cerrar"  class="d-none btn btn-info btn-block">Cerrar Disco</a>  
		      		     
		     <!-- Formulario CD --> 
		     <div id="formulariocd" >
		      <form id="collapse" >
			        <input id="id_disco" name="disco" value="1" class="d-none">			        
			  </form>    
			 </div> 
			 <!-- Formulario CD -->

			  <!-- Contenido CD Diferente -->
			  <div id="cont_cd1" class="collapse ">
			  	<br>
			  	<?php echo diferente(); ?>
			    
			  </div>
			  <!-- Contenido CD Diferente -->

		  </div>
		</div>


		<!-- CD QUIERO AMARTE -->